class SStack():
    def __init__(self):
        self.elems = []

    def is_empty(self):
        return self.elems == []

    def top(self):
        if self.elems == []:
            raise StackUnderflow
        return self.elems[len(self.elems) - 1]

    def push(self, elem):
        self.elems.append(elem)

    def pop(self):
        if self.elems == []:
            raise StackUnderflow
        return self.elems.pop()




class ESStack(SStack):
    def depth(self):
        return len(self.elems)


def suffix_exp_evaluator(line):
    return suf_exp_evaluator(line.split())


def suf_exp_evaluator(exp):
    """exp is a list of items representing a suffix expression.
    This function evaluates it and return its value.
    """
    operators = "+-*/"
    st = ESStack()
    for x in exp:
        if not x in operators:
            st.push(float(x))
            continue
        if st.depth() < 2:
            raise SyntaxError("Short of operand(s).")
        a = st.pop()  # second argument
        b = st.pop()  # first argument
        if x == "+":
            c = b + a
        elif x == "-":
            c = b - a
        elif x == "*":
            c = b * a
        elif x == "/":
            if a == 0: raise ZeroDivisionError
            c = b / a
        else:
            pass  # This branch is not possible
        st.push(c)
    if st.depth() == 1:
        return st.pop()
    raise SyntaxError("Extra operand(s).")

#import sys
#line=input().split()
#line=[int(x) for x in line]
#m,n=line[0],line[1]

import sys
lst = []
lineNum = 0
for line in sys.stdin:
    if(lineNum == 0):
        scol, srow = line.strip().split(' ')
        m, n = int(scol),int(srow)
    else:
        lst.append(line.strip('\n'))
    lineNum += 1

print(m,n)


#m = 2
#n = 3

letters = [chr(i) for i in range(65,91)]




import pandas as pd
import numpy as np
#lst= ['A2', '4 5 *', 'A1', 'A1 B2 / 2 + ','3', '39 B1 B2 * /']

aa = np.array(lst,dtype=object)
aa.shape = (m,n)

df = pd.DataFrame(aa,index = letters[:m],columns = range(1,n+1),dtype=str)

print(df)

import re

row = 0
hasLetter = False
ischanging = True

while hasLetter or row < m:

    if ischanging == False and hasLetter == True and row == m:
        print("Error:Circular Dependency!")
        break

    if (row == m):
        row = 0
        ischanging = False
        hasLetter = False

    for col in range(1, n + 1):
        print("here row,col, ischanging, ", row, col, df.ix[letters[row], col], ischanging)
        if re.search(r'[A-Z]', df.ix[letters[row], col]):
            hasLetter = True
            expr = df.ix[letters[row], col].split(' ')
            # print(expr)
            nexpr = ''
            for element in expr:
                # print("element",element)
                if not re.search(r'[A-Z]', element):
                    nexpr = nexpr + element + ' '
                else:
                    # print(element,"and",expr)
                    findrow = element[0]
                    findcol = int(element[1:])
                    try:
                        c = format(float(df.ix[findrow, findcol]), '.5f')
                        nexpr = nexpr + str(c) + ' '
                        ischanging = True  # Saying that the data.frame is updating
                    except:
                        if not re.search(r'[A-Z]', df.ix[findrow, findcol]):
                            ischanging = True

                        nexpr = nexpr + element + ' '

            # print("new expression", nexpr)
            df.ix[letters[row], col] = nexpr

        else:
            try:
                isinstance(float(df.ix[letters[row], col]), float)
            except:

                # if re.search(r'[\+\-\*\/]',df.ix[letters[row], col]):
                value = format(suffix_exp_evaluator(df.ix[letters[row], col]), '.5f')
                df.ix[letters[row], col] = str(value)
                ischanging = True  # Saying that the data.frame is updating
            # else:
            #    continue
            print("now", df.ix[letters[row], col])

    row += 1

print("\n\n Result of df\n", df,'\n\n')

output = ''
for row in range(m):
    for col in range(1,n+1):
        output += df.ix[letters[row],col]+'\n'

sys.stdout.write(output)
