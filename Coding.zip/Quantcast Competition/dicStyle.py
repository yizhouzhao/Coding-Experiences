'''
Created on 11/5/2016
@author: Yizhou Zhao
@Email:yizhou_zhao@berkeley.edu

For QuantCast Coding Challenge
'''

import sys
import re


#Define a functino to get the value from RPN expression
def suffix_exp_evaluator(line):
    return suf_exp_evaluator(line.split())

def suf_exp_evaluator(exp):
    """exp is a list of items representing a suffix expression.
    This function evaluates it and return its value.
    """
    # Define a stack
    class MyStack():
        def __init__(self):
            self.elems = []

        def is_empty(self):
            return self.elems == []

        def top(self):
            if self.elems == []:
                raise StackUnderflow # Rasie error when the stack is empty
            return self.elems[len(self.elems) - 1]

        def push(self, elem):
            self.elems.append(elem)

        def pop(self):
            if self.elems == []:
                raise StackUnderflow # Rasie error when the stack is empty
            return self.elems.pop()

    # Define a stack with depth
    class EMyStack(MyStack):
        def depth(self):
            return len(self.elems)

    operators = "+-*/"
    st = EMyStack()
    for x in exp:
        if not x in operators:
            st.push(float(x))
            continue
        if st.depth() < 2:
            raise SyntaxError("Short of operand(s).")
        a = st.pop()  # second argument
        b = st.pop()  # first argument
        if x == "+":
            c = b + a
        elif x == "-":
            c = b - a
        elif x == "*":
            c = b * a
        elif x == "/":
            if a == 0: raise ZeroDivisionError
            c = b / a
        else:
            pass  # This branch is not possible
        st.push(c)
    if st.depth() == 1:
        return st.pop()
    raise SyntaxError("Extra operand(s).")

lst = [] #Define a list to store the lines which read from stdin
lineNum = 0
for line in sys.stdin:
    if(lineNum == 0):
        #The fist line is the number of cols and the number of rows.
        scol, srow = line.strip().split(' ')
        n, m = int(scol),int(srow)
    else:
        #The rest of line is the value of the cells.
        lst.append(line.strip('\n'))
    lineNum += 1

#Get the upper case letters
letters = [chr(i) for i in range(65,91)]

#Generate a dictionary to store the data
df = {}
for i in range(m):
    df[letters[i]] = []
    for j in range(n):
        #print(i,j)
        df[letters[i]].append(lst[i*n+j])



row = 0 # Index to traverse the data dictionary

hasLetter = False # Indicator to judge whether there are any expressions containing letters in the dictionary
ischanging = True # Indicator to judge whether the dictionary is updating while being traversed



while hasLetter or row < m:
    '''
    Algorithm:　Greedy Method, traverse the cells of the data dictionary(df) and updating it:
        if the cell does not contain any letters(such as A2, B1), then apply the RPN evaluator the get its value
        if the cell contains some letters, try to simplify the expression by finding the value at which \
            it is pointing. for example, replace B1 A8 / with 20 A8 /

    The space cost of the algorithm is O(mn), mainly used to store the data dictionary
    The time cost of the algorithm is O(mn), mainly used to traverse the data dictionary
    '''

    if ischanging == False and hasLetter == True and row == m:
        # Raise CircularDependencyError when traversing the data dictionary and found nothing can be updated
        print("Error:Circular Dependency!")
        raise CircularDependencyError
        break


    if (row == m):
        row = 0
        ischanging = False
        hasLetter = False


    for col in range(1, n+1):
        if re.search(r'[A-Z]', df[letters[row]][col-1]):
            hasLetter = True
            expr = df[letters[row]][col-1].split(' ')

            nexpr = '' # Updated expression of the cell
            for element in expr:

                if not re.search(r'[A-Z]', element):
                    nexpr = nexpr + element + ' '
                else:
                    findrow = element[0]
                    findcol = int(element[1:])

                    try:
                        c = format(float(df[findrow][findcol-1]), '.5f') # keep 5 decimal places
                        nexpr = nexpr + str(c) + ' '
                        ischanging = True  # Data.frame is updating
                    except:
                        if not re.search(r'[A-Z]', df[findrow][findcol-1]):
                            ischanging = True

                        nexpr = nexpr + element + ' '

            df[letters[row]][col-1] = nexpr

        else:
            try:
                isinstance(float(df[letters[row]][col-1]), float)
                df[letters[row]][col-1] = str(format(float(df[letters[row]][col-1]),'.5f')) #keep 5 decimal places
            except:
                value = format(suffix_exp_evaluator(df[letters[row]][col-1]), '.5f')
                df[letters[row]][col-1] = str(value)
                ischanging = True  #Data.frame is updating

    row += 1

# Generate the Stdout
output = ''
for row in range(m):
    for col in range(0,n):
        output += df[letters[row]][col]+'\n'

sys.stdout.write(output)
