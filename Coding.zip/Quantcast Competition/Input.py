import sys
import numpy as np
import pandas as pd

letters = [chr(i) for i in range(64,91)]

class SpreadSheet:
    rowNum = 0
    colNum = 0
    cells = {}
    tools = {}
    def __setitem__(self, key, formula):
        self.cells[key] = formula
    def getformula(self, key):
        return self.cells[key]
    def __getitem__(self, key ):
        return eval(self.cells[key], SpreadSheet.tools, self)


ss = SpreadSheet()

lineNum = 0
col = 0
row = 0

import sys
lst = []
for line in sys.stdin:
    print(line)
    if(lineNum == 0):
        scol, srow = line.strip().split(' ')
        col, row = int(scol),int(srow)
    else:
        lst.append(line.strip('\n'))
    lineNum += 1

print(lst)









