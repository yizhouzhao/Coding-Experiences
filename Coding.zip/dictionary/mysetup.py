# mysetup.py

from distutils.core import setup
import py2exe

setup(windows=['1.py'])
#'icon_resources': [(1, 'C:\Users\heitangtang\Downloads\icon.ico')]}],compress = 1, bundle_files = 3, zipfile = None)

